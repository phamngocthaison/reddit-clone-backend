"""Authentication Lambda functions."""
