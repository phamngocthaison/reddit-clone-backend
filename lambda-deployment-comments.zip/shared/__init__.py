"""Shared utilities and models."""
